import datetime
from tkinter import *
import tkinter.messagebox as mb
from tkinter import ttk
from tkcalendar import DateEntry
import mysql.connector


# Connect to the MySQL database
mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="tuition_booking_system"
)

# Create a cursor to execute SQL queries
mycursor = mydb.cursor()

# Create the STUDENT_INFORMATION table if it doesn't exist
mycursor.execute
(
"CREATE TABLE IF NOT EXISTS STUDENT_INFORMATION (NAME TEXT, EMAIL TEXT, PHONE_NO TEXT, GENDER TEXT, DOB TEXT, SUBJECT TEXT)"
)


# Function to reset the input fields
def reset_fields():
    global name_strvar, email_strvar, contact_strvar, gender_strvar, dob, subject_strvar

    name_strvar.set('')
    email_strvar.set('')
    contact_strvar.set('')
    gender_strvar.set('')
    dob.set_date(datetime.datetime.now().date())
    subject_strvar.set('')


# Function to reset the entire form
def reset_form():
    global tree
    tree.delete(*tree.get_children())
    reset_fields()


# Function to display records in the treeview
def display_records():
    tree.delete(*tree.get_children())

    try:
        mycursor.execute('SELECT * FROM STUDENT_INFORMATION')
        data = mycursor.fetchall()

        for records in data:
            tree.insert('', END, values=records)
    except mysql.connector.Error as error:
        mb.showerror('Database Error', str(error))


# Function to add a new record to the database
def add_record():
    global name_strvar, email_strvar, contact_strvar, gender_strvar, dob, subject_strvar

    name = name_strvar.get()
    email = email_strvar.get()
    contact = contact_strvar.get()
    gender = gender_strvar.get()
    DOB = dob.get_date()
    subject = subject_strvar.get()

    if not name or not email or not contact or not gender or not DOB or not subject:
        mb.showerror('Error!', "Please fill all the missing fields!!")
    else:
        try:
            mycursor.execute(
                'INSERT INTO STUDENT_INFORMATION (NAME, EMAIL, PHONE_NO, GENDER, DOB, SUBJECT) VALUES (%s,%s,%s,%s,%s,%s)',
                (name, email, contact, gender, DOB, subject)
            )
            mydb.commit()
            mb.showinfo('Record added', f"Record of {name} was successfully added")
            reset_fields()
            display_records()
        except mysql.connector.Error as error:
            mb.showerror('Database Error', str(error))


# Function to remove a record from the database
def remove_record():
    if not tree.selection():
        mb.showerror('Error!', 'Please select an item from the database')
    else:
        current_item = tree.focus()
        values = tree.item(current_item)
        selection = values["values"]

        tree.delete(current_item)

        try:
            mycursor.execute('DELETE FROM STUDENT_INFORMATION WHERE NAME=%s', (selection[0],))
            mydb.commit()
            mb.showinfo('Done', 'The record you wanted deleted was successfully deleted.')
            display_records()
        except mysql.connector.Error as error:
            mb.showerror('Database Error', str(error))


# Function to update a record in the database
def update_record():
    global name_strvar, email_strvar, contact_strvar, gender_strvar, dob, subject_strvar

    current_item = tree.focus()
    values = tree.item(current_item)
    selection = values["values"]

    old_name = selection[0]

    new_name = name_strvar.get()
    email = email_strvar.get()
    contact = contact_strvar.get()
    gender = gender_strvar.get()
    dob_value = dob.get_date()
    subject = subject_strvar.get()

    if not new_name or not email or not contact or not gender or not dob_value or not subject:
        mb.showerror('Error!', "Please fill all the missing fields!!")
    else:
        try:
            mycursor.execute(
                'UPDATE STUDENT_INFORMATION SET NAME=%s, EMAIL=%s, PHONE_NO=%s, GENDER=%s, DOB=%s, SUBJECT=%s WHERE NAME=%s',
                (new_name, email, contact, gender, dob_value, subject, old_name)
            )
            mydb.commit()
            mb.showinfo('Record updated', f"Record of {old_name} was successfully updated to {new_name}")
            reset_fields()
            display_records()
        except mysql.connector.Error as error:
            mb.showerror('Database Error', str(error))


# Function to create a text file with the database records
def create_text_file():
    try:
        mycursor.execute('SELECT * FROM STUDENT_INFORMATION')
        data = mycursor.fetchall()

        file_name = "student_records.txt"
        with open(file_name, 'w') as file:
            for record in data:
                file.write(f"Name: {record[0]}\n")
                file.write(f"Email: {record[1]}\n")
                file.write(f"Phone No: {record[2]}\n")
                file.write(f"Gender: {record[3]}\n")
                file.write(f"DOB: {record[4]}\n")
                file.write(f"Subject: {record[5]}\n")
                file.write("\n")
        
        mb.showinfo('File Created', f"The text file '{file_name}' was successfully created.")
    except mysql.connector.Error as error:
        mb.showerror('Database Error', str(error))


# Create the main Tkinter window
main = Tk()
main.title('Tution Booking System')
main.geometry('1000x700')
main.resizable(TRUE, TRUE)

headlabelfont = ("Noto Sans CJK TC", 15, 'bold')
labelfont = ('Garamond', 14)
entryfont = ('Garamond', 12)

lf_bg = 'lightcoral'
cf_bg = 'lightpink'

name_strvar = StringVar()
email_strvar = StringVar()
contact_strvar = StringVar()
gender_strvar = StringVar()
subject_strvar = StringVar()

# GUI elements and layout
Label(main, text="TUITION BOOKING SYSTEM", font=headlabelfont, bg='lightcoral').pack(side=TOP, fill=X)

left_frame = Frame(main, bg=lf_bg)
left_frame.place(x=0, y=30, relheight=1, relwidth=0.2)

center_frame = Frame(main, bg=cf_bg)
center_frame.place(relx=0.2, y=30, relheight=1, relwidth=0.2)

right_frame = Frame(main, bg="Gray35")
right_frame.place(relx=0.4, y=30, relheight=1, relwidth=0.6)

Label(left_frame, text="Name", font=labelfont, bg=lf_bg).place(relx=0.375, rely=0.05)
Label(left_frame, text="Subject", font=labelfont, bg=lf_bg).place(relx=0.3, rely=0.18)
Label(left_frame, text="Contact Number", font=labelfont, bg=lf_bg).place(relx=0.175, rely=0.31)
Label(left_frame, text="Gender", font=labelfont, bg=lf_bg).place(relx=0.3, rely=0.7)
Label(left_frame, text="Email Address", font=labelfont, bg=lf_bg).place(relx=0.275, rely=0.44)
Label(left_frame, text="Date of Birth", font=labelfont, bg=lf_bg).place(relx=0.275, rely=0.57)

Entry(left_frame, font=entryfont, textvariable=name_strvar).place(relx=0.125, rely=0.1)
Entry(left_frame, font=entryfont, textvariable=contact_strvar).place(relx=0.125, rely=0.35)
Entry(left_frame, font=entryfont, textvariable=email_strvar).place(relx=0.125, rely=0.5)

dob = DateEntry(left_frame, width=19, background='lightpink', foreground='black', borderwidth=2, date_pattern='dd-mm-yyyy')
dob.place(relx=0.125, rely=0.63)

ttk.Combobox(left_frame, values=["Math", "Bahasa Melayu", "Python Programming", "Web Design Technology"
                                 ], textvariable=subject_strvar).place(relx=0.125, rely=0.22)
ttk.Combobox(left_frame, values=["Male", "Female"], textvariable=gender_strvar).place(relx=0.125, rely=0.8)

Button(left_frame, text="Submit", bg='lightpink', relief=GROOVE, font=('Arial', 12, 'bold'), command=add_record).place(
    relx=0.15, rely=0.9)

tree = ttk.Treeview(right_frame, column=("c1", "c2", "c3", "c4", "c5", "c6"), show='headings')
tree.column("#1", anchor=CENTER)
tree.heading("#1", text="Name")
tree.column("#2", anchor=CENTER)
tree.heading("#2", text="Email")
tree.column("#3", anchor=CENTER)
tree.heading("#3", text="Phone No")
tree.column("#4", anchor=CENTER)
tree.heading("#4", text="Gender")
tree.column("#5", anchor=CENTER)
tree.heading("#5", text="DOB")
tree.column("#6", anchor=CENTER)
tree.heading("#6", text="Subject")
tree.pack(fill=BOTH, expand=1)

Button(center_frame, text="Reset Form", bg='lightcoral', relief=GROOVE, font=('Arial', 12, 'bold'), command=reset_form
       ).place(relx=0.05, rely=0.1)

Button(center_frame, text="Display Records", bg='lightcoral', relief=GROOVE, font=('Arial', 12, 'bold'), command=display_records
       ).place(relx=0.05, rely=0.275)

Button(center_frame, text="Delete Record", bg='lightcoral', relief=GROOVE, font=('Arial', 12, 'bold'), command=remove_record
       ).place(relx=0.05, rely=0.45)

Button(center_frame, text="Update Record", bg='lightcoral', relief=GROOVE, font=('Arial', 12, 'bold'), command=update_record
       ).place(relx=0.05, rely=0.625)

Button(center_frame, text="Create Text File", bg='lightcoral', relief=GROOVE, font=('Arial', 12, 'bold'), command=create_text_file
       ).place(relx=0.05, rely=0.8)

# Display existing records in the treeview
display_records()

# Run the main Tkinter event loop
main.mainloop()
